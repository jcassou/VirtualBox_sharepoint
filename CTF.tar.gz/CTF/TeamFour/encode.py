import base64

with open("test/test.flag.gpg", "rb") as gpg_file:
    encoded_string = base64.b64encode(gpg_file.read())

print(encoded_string);
