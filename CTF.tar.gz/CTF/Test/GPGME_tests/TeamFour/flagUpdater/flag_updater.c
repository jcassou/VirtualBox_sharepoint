#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <gpgme.h>
#include <locale.h> 
#include <errno.h>

char* PATH_FLAG = "/var/ctf/";
int PATH_MAX = 1024;
int BUFSIZE = 1024;

void fail_if_err(gpgme_error_t err){
	if (err){
		fprintf (stderr, "%s:%d: %s: %s\n",
				__FILE__, __LINE__, gpgme_strsource (err),
				gpgme_strerror (err));
		exit (1);
	}
}

void init_gpgme(gpgme_protocol_t proto){
	gpgme_error_t err;

	gpgme_check_version (NULL);
	setlocale (LC_ALL, "");
	gpgme_set_locale (NULL, LC_CTYPE, setlocale (LC_CTYPE, NULL));
#ifndef HAVE_W32_SYSTEM
	gpgme_set_locale (NULL, LC_MESSAGES, setlocale (LC_MESSAGES, NULL));
#endif

	err = gpgme_engine_check_version (proto);
	fail_if_err (err);

}

void print_data (gpgme_data_t dh){
#define BUF_SIZE 512
	char buf[BUF_SIZE + 1];
	int ret;

	ret = gpgme_data_seek (dh, 0, SEEK_SET);
	if (ret)
		fail_if_err (gpgme_err_code_from_errno (errno));
	while ((ret = gpgme_data_read (dh, buf, BUF_SIZE)) > 0)
		fwrite (buf, ret, 1, stdout);
	if (ret < 0)
		fail_if_err (gpgme_err_code_from_errno (errno));

	/* Reset read position to the beginning so that dh can be used as input
	   for another operation after this method call. For example, dh is an
	   output from encryption and also is used as an input for decryption.
	   Otherwise GPG_ERR_NO_DATA is returned since this method moves the
	   read position. */
	ret = gpgme_data_seek (dh, 0, SEEK_SET);
}

void daemonize(void)
{
	pid_t pid, sid;
	pid = fork();

	if(pid < 0)
		exit( EXIT_FAILURE );
	else if(pid > 0)
		exit( EXIT_SUCCESS );

	umask(0);

	sid = setsid();

	if(sid < 0)
	{
		perror("daemonize::sid");
		exit( EXIT_FAILURE );
	}

	//close(STDIN_FILENO);
	//close(STDOUT_FILENO);
	//close(STDERR_FILENO);
}

int verify_signature(char buf[BUFSIZE]){
	FILE *fp, *sed;
	char path[PATH_MAX];
	char new_buf[BUFSIZE];
	int disc = 10;

	// GPG Decryption
/*
	char *p;

	gpgme_ctx_t ceofcontext;
	gpgme_error_t err;
	gpgme_data_t data;
	gpgme_ctx_t ctx;
	gpgme_data_t encrypt, decrypt;
	gpgme_genkey_result_t gen_result;
	gpgme_encrypt_result_t enc_result;
	gpgme_decrypt_result_t dec_result;
	gpgme_key_t keys[1] = {NULL, NULL};

	// Initialize GPGME 

        gpgme_check_version (NULL);
	
	err = gpgme_engine_check_version (GPGME_PROTOCOL_OpenPGP);
        fail_if_err (err);

	err = gpgme_new (&ctx); //creation of the context
	fail_if_err(err);

	gpgme_op_import_keys(ctx, keys);
	
	// Decrypt 
	gpgme_op_decrypt(ctx, buf, decrypt);

	print_data(decrypt);
*/

	puts(buf);

	fp = fopen("encrypt.flag.gpg", "w+");
        fprintf(fp, "%s", buf);
        fclose(fp);

        fp = popen("gpg --import keys/notary_key.pub", "r"); //import TEAM_4 public key 
        fgets(path, PATH_MAX, fp);
        pclose(fp);

	fp = popen(" gpg --decrypt encrypt.flag.gpg > decrypt.flag", "r"); //put pid from running processes into a log file 
        fgets(path, PATH_MAX, fp);
        pclose(fp);
	
	// Extract data from the json file

	const char s[2] = "\"";
	char *token;
	char signature[100];
	char githubID[100];
	char newflag[100];
	char carac;
	char line[100];
	int i = 0;

	fp = fopen("/var/ctf/verif.flag", "w+");
	fprintf(fp, "%s", buf);
	fclose(fp);

	sed = fopen("/var/ctf/verif.flag", "r");

	while (fgets(line, sizeof(line), sed) != NULL){
		if(line != "\n"){
			line[strlen(line) - 1] = '\0';

			char *data = strdup(line);

			token = strtok(data, s);
			while( token != NULL ){
				i++;
				if(i == 5){
					strcpy(githubID, token);
				}
				if(i == 10){
					strcpy(newflag, token);
				}
				if(i == 15){
					strcpy(signature, token);	
				}
				token = strtok(NULL, s);
			}
		}
	}

	fclose(sed);

	printf("Github ID : %s\n", githubID);
	printf("Signature : %s\n", signature);
	printf("New Flag : %s\n", newflag);

	/* Verify the signature */

	char check_signature[100];

	strcpy(check_signature, githubID);
	strcat(check_signature, ":");
	strcat(check_signature, newflag);

	puts(check_signature);

	//TODO : Sign the string with the PGP key of the id

	return 0;

}

void listen_client(){
	FILE *fp;
	int parentfd; /* parent socket */
	int childfd; /* child socket */
	int clientlen; /* byte size of client's address */
	struct sockaddr_in serveraddr; /* server's addr */
	struct sockaddr_in clientaddr; /* client addr */
	struct hostent *hostp; /* client host info */
	char buf[BUFSIZE]; /* message buffer */
	char *hostaddrp; /* dotted decimal host addr string */
	int optval; /* flag value for setsockopt */
	int n; /* message byte size */
	int portno = 4200;

	fp = fopen ("/var/ctf/notary.flag", "w+");
	if(fp == NULL){
		perror("ERROR opening notary.flag");
	}

	// Create the parent socket 
	parentfd = socket(AF_INET, SOCK_STREAM, 0);
	if (parentfd < 0)
		perror("ERROR opening socket");

	optval = 1;
	setsockopt(parentfd, SOL_SOCKET, SO_REUSEADDR,
			(const void *)&optval , sizeof(int));

	// Build the server's Internet address 
	bzero((char *) &serveraddr, sizeof(serveraddr));

	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons((unsigned short)portno);

	// Associate the parent socket with a port 
	if (bind(parentfd, (struct sockaddr *) &serveraddr,
				sizeof(serveraddr)) < 0)
		perror("ERROR on binding");

	// Make this socket ready to accept connection requests 
	if (listen(parentfd, 5) < 0) // allow 5 requests to queue up
		perror("ERROR on listen");

	// Wait for a connection request, echo input line, then close connection 
	clientlen = sizeof(clientaddr);
	while (1) {

		// Wait for a connection request 
		childfd = accept(parentfd, (struct sockaddr *) &clientaddr, &clientlen);
		if (childfd < 0)
			perror("ERROR on accept");

		// Determine who sent the message 
		hostp = gethostbyaddr((const char *)&clientaddr.sin_addr.s_addr,
				sizeof(clientaddr.sin_addr.s_addr), AF_INET);
		if (hostp == NULL)
			perror("ERROR on gethostbyaddr");
		hostaddrp = inet_ntoa(clientaddr.sin_addr);
		if (hostaddrp == NULL)
			perror("ERROR on inet_ntoa\n");
		printf("server established connection with %s (%s)\n",
				hostp->h_name, hostaddrp);

		// Read input string from the client 
		bzero(buf, BUFSIZE);
		n = read(childfd, buf, BUFSIZE);
		if (n < 0)
			perror("ERROR reading from socket");
		printf("server received %d bytes: %s", n, buf);

		/* Test */
		//strcpy(buf, "{\n \"signer\" : \"TAsID\",\n  \"newflag\": \"1234567890ABCDEF\",\n  \"signature\" : \"zdjchnuydyziybctu2657BKKJJH\"\n}");

		if(verify_signature(buf) == -1){
			perror("The signature of the file isn't good\n");
		}else{
			//Updates the content of the file
			fp = fopen ("/var/ctf/notary.flag", "w+");
			if(fp == NULL){
				perror("ERROR opening notary.flag");
			}
			fprintf(fp, "%s", buf);
			fclose(fp);
		}
		close(childfd);
	}
}

int main(void)
{
	daemonize();
	listen_client();	
	return( EXIT_SUCCESS );
}
